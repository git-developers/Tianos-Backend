<?php

declare(strict_types=1);

namespace Bundle\DUMMY_UPPERBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DUMMY_UPPERBundle extends Bundle
{

}


//
//namespace Bundle\CRUDDUMMYBundle;
//
//use Sylius\Bundle\ResourceBundle\AbstractResourceBundle;
//use Sylius\Bundle\ResourceBundle\ResourceBundle;
//
//final class CRUDDUMMYBundle extends AbstractResourceBundle
//{
//    /**
//     * {@inheritdoc}
//     */
//    public function getSupportedDrivers(): array
//    {
//        return [
//            SyliusResourceBundle::DRIVER_DOCTRINE_ORM,
//        ];
//    }
//
//    /**
//     * {@inheritdoc}
//     */
//    protected function getModelNamespace(): string
//    {
//        return 'Sylius\Component\CRUDDUMMY\Model';
//    }
//}
